import React from 'react'

function Resume() {
  return (
    <div className={`w-screen h-screen bg-blue-900 flex justify-center items-center text-white`}>Resume</div>
  )
}

export default Resume